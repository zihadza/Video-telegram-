"""
Telegram Bot handlers using PyroTGFork MTProto.
Handles commands, file uploads, and inline callbacks.
"""

import secrets
import string
from datetime import datetime, timedelta
from pyrogram import filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from sqlalchemy import select, func

from .telegram import tg_client, forward_to_storage_channel
from .database import async_session
from .models import User, File, Folder, LoginCode
from .config import get_settings
from .auth import create_access_token

settings = get_settings()


def format_size(size_bytes: int) -> str:
    """Format bytes to human readable size."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def format_duration(seconds: int) -> str:
    """Format seconds to human readable duration."""
    if not seconds:
        return ""
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m {secs}s"


def sanitize_filename(name: str) -> str:
    """
    Sanitize filename to prevent path traversal and XSS attacks.
    Removes dangerous characters and limits length.
    """
    import re
    if not name:
        return "unnamed_file"
    
    # Remove null bytes and path separators
    name = name.replace("\x00", "").replace("/", "_").replace("\\", "_")
    
    # Remove other dangerous characters that could cause issues
    name = re.sub(r'[<>:"|?*\x00-\x1f]', '_', name)
    
    # Remove leading/trailing dots and spaces (Windows issues)
    name = name.strip(". ")
    
    # Limit length to prevent issues
    if len(name) > 255:
        # Keep extension if present
        if "." in name:
            ext = name.rsplit(".", 1)[-1][:10]  # Max 10 char extension
            name = name[:255 - len(ext) - 1] + "." + ext
        else:
            name = name[:255]
    
    return name if name else "unnamed_file"


async def get_or_create_user(telegram_id: int, username: str = None, 
                             first_name: str = None, last_name: str = None) -> User:
    """Get or create a user in the database."""
    async with async_session() as db:
        result = await db.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        
        if not user:
            user = User(
                telegram_id=telegram_id,
                username=username,
                first_name=first_name,
                last_name=last_name,
            )
            db.add(user)
            await db.commit()
            await db.refresh(user)
        
        return user


def get_web_app_button(telegram_id: int, text: str = "🌐 Open Web") -> InlineKeyboardButton:
    """Create a URL button with authenticated link."""
    from urllib.parse import quote
    token = create_access_token(telegram_id)
    encoded_token = quote(token, safe='')
    web_url = f"{settings.web_base_url}/auth?token={encoded_token}"
    return InlineKeyboardButton(text, web_app=WebAppInfo(url=web_url))

# ============== Authorization Middleware ==============

@tg_client.on_message(filters.private, group=-2)
async def check_auth(client, message: Message):
    """Check if the user is authorized to use the bot."""
    auth_users = settings.auth_users
    if not auth_users:
        # Open to everyone
        return
    
    if message.from_user.id not in auth_users:
        # Ignore if it's a command we don't want to reply to (to avoid spamming unauthorized users)
        # But for /start, we should give a polite rejection
        if message.text and message.text.startswith("/start"):
            await message.reply(
                "🚫 **Access Restricted**\n\n"
                "Sorry, this bot is limited to authorized users only.\n"
                f"Your Telegram ID: `{message.from_user.id}`"
            )
        
        # Stop further processing of this message
        message.stop_propagation()

# ============== Command Handlers ==============

@tg_client.on_message(filters.command("start") & filters.private)
async def start_command(client, message: Message):
    """Welcome message and bot instructions. Also handles deep-linked login codes."""
    await get_or_create_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
    )
    
    # Check for deep-linked login codes (e.g. /start ABCDEF)
    if len(message.command) > 1:
        code_input = message.command[1].strip().upper()
        async with async_session() as db:
            result = await db.execute(select(LoginCode).where(LoginCode.code == code_input))
            login_code = result.scalar_one_or_none()
            
            if login_code:
                if login_code.expires_at > datetime.utcnow() and not login_code.telegram_id:
                    # Claim the code
                    login_code.telegram_id = message.from_user.id
                    await db.commit()
                    
                    await message.reply(
                        "✅ **Success!**\n"
                        "You have successfully logged in on your device.\n"
                        "You can now enjoy watching! 🍿"
                    )
                    return
                elif login_code.telegram_id:
                     await message.reply("⚠️ This code has already been used.")
                     return
                else:
                     await message.reply("❌ This code has expired.")
                     return

    await message.reply(
        "📺 **Welcome to TelePlay!**\n\n"
        "Your personal media streaming platform.\n"
        "Upload files here, stream anywhere!\n\n"
        
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🚀 **QUICK START**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "1️⃣ Send any media file to upload\n"
        "2️⃣ Use /web to open web player\n"
        "3️⃣ Use /login on your TV app\n\n"
        
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📝 **COMMANDS**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "/myfiles - Your files with IDs\n"
        "/file `<id>` - Manage a file\n"
        "/folders - Browse folders\n"
        "/newfolder `<name>` - New folder\n"
        "/help - Full help guide\n\n"
        
        "💡 After uploading, you'll get the **File ID**\n"
        "Use `/file <id>` to rename, move, or delete.",
        reply_markup=InlineKeyboardMarkup([
            [get_web_app_button(message.from_user.id, "🌐 Open Web Interface")],
            [
                InlineKeyboardButton("📁 My Files", callback_data="show_files"),
                InlineKeyboardButton("📂 My Folders", callback_data="back_folders")
            ]
        ])
    )


@tg_client.on_message(filters.command("help") & filters.private)
async def help_command(client, message: Message):
    """Show help message."""
    await message.reply(
        "📖 **TelePlay Help**\n\n"
        
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📤 **UPLOADING FILES**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Simply send any video, audio, image or document to me.\n"
        "I'll save it to your library for streaming.\n\n"
        
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📋 **COMMANDS**\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        
        "**General:**\n"
        "• /start - Welcome message\n"
        "• /help - This help message\n"
        "• /web - Get authenticated web link\n"
        "• /login - Get/verify login code for TV\n"
        "• /logout_all - Invalidate all active sessions\n\n"
        
        "**File Management:**\n"
        "• /myfiles - List your recent files with IDs\n"
        "• /file `<id>` - Manage a specific file\n"
        "  ↳ Rename, Move, Delete, Open Web\n\n"
        
        "**Folder Management:**\n"
        "• /folders - Browse all folders\n"
        "• /newfolder `<name>` - Create a folder\n"
        "• /deletefolder `<name>` - Delete a folder\n\n"
        
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🎛 **INTERACTIVE ACTIONS**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "When you tap buttons, I'll ask for input:\n"
        "• **Rename** - Send new name (60s timeout)\n"
        "• **Create Folder** - Send folder name\n"
        "• **Delete** - Tap confirm or cancel\n"
        "• **Move** - Select destination folder\n\n"
        "💡 Send /cancel to abort any action\n\n"
        
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📁 **SUPPORTED FILES**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "• 🎬 Videos: MP4, MKV, AVI, MOV, WEBM\n"
        "• 🎵 Audio: MP3, FLAC, AAC, OGG, WAV\n"
        "• 🖼 Images: JPG, PNG, GIF, WEBP\n"
        "• 📄 Documents: PDF, TXT, DOCX, etc.\n"
        "• ⚠️ Max size: 2GB per file\n\n"
        
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📺 **TV & WEB STREAMING**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "• Use /web to get a secure link\n"
        "• Use /login on TV app to connect\n"
        "• Watch progress syncs across devices\n"
    )


@tg_client.on_message(filters.command("myfiles") & filters.private)
async def myfiles_command(client, message: Message):
    """List user's recent files."""
    async with async_session() as db:
        result = await db.execute(
            select(File)
            .where(File.user_id == (
                select(User.id).where(User.telegram_id == message.from_user.id).scalar_subquery()
            ))
            .order_by(File.created_at.desc())
            .limit(10)
        )
        files = result.scalars().all()
    
    if not files:
        await message.reply(
            "📭 You haven't uploaded any files yet.\n\n"
            "Send me a video, audio, or document to get started!"
        )
        return
    
    text = "📁 **Your Recent Files:**\n\n"
    
    for f in files:
        emoji = {"video": "🎬", "audio": "🎵", "document": "📄", "image": "🖼"}.get(f.file_type, "📎")
        text += f"{emoji} `{f.id}` | {f.file_name}\n   └ {format_size(f.file_size)}"
        if f.duration:
            text += f" • {format_duration(f.duration)}"
        text += "\n\n"
    
    text += "💡 Use /file <id> to manage a file"
    
    await message.reply(
        text,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📁 My Folders", callback_data="back_folders")],
            [get_web_app_button(message.from_user.id, "🌐 Open Web")]
        ])
    )


@tg_client.on_message(filters.command("folders") & filters.private)
async def folders_command(client, message: Message):
    """Show folder structure."""
    async with async_session() as db:
        # Get user
        user_result = await db.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = user_result.scalar_one_or_none()
        
        if not user:
            await message.reply("Please use /start first.")
            return
        
        # Get root folders
        result = await db.execute(
            select(Folder)
            .where(Folder.user_id == user.id, Folder.parent_id.is_(None))
            .order_by(Folder.name)
        )
        folders = result.scalars().all()
    
    if not folders:
        await message.reply(
            "📁 You don't have any folders yet.\n\n"
            "Create one with /newfolder <name>",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("➕ Create Folder", callback_data="create_folder")]
            ])
        )
        return
    
    buttons = []
    for f in folders:
        buttons.append([
            InlineKeyboardButton(f"📂 {f.name}", callback_data=f"folder:{f.id}")
        ])
    buttons.append([InlineKeyboardButton("➕ Create Folder", callback_data="create_folder")])
    
    await message.reply(
        "📁 **Your Folders:**",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


@tg_client.on_message(filters.command("newfolder") & filters.private)
async def newfolder_command(client, message: Message):
    """Create a new folder."""
    if len(message.command) < 2:
        await message.reply("Usage: /newfolder <folder_name>")
        return
    
    folder_name = " ".join(message.command[1:])
    
    async with async_session() as db:
        # Get user
        user_result = await db.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = user_result.scalar_one_or_none()
        
        if not user:
            await message.reply("Please use /start first.")
            return
        
        # Check if folder exists
        existing = await db.execute(
            select(Folder).where(
                Folder.user_id == user.id,
                Folder.name == folder_name,
                Folder.parent_id.is_(None)
            )
        )
        if existing.scalar_one_or_none():
            await message.reply(f"❌ Folder **{folder_name}** already exists.")
            return
        
        # Create folder
        folder = Folder(user_id=user.id, name=folder_name)
        db.add(folder)
        await db.commit()
    
    await message.reply(f"✅ Folder **{folder_name}** created!")


@tg_client.on_message(filters.command("web") & filters.private)
async def web_command(client, message: Message):
    """Get authenticated web interface link."""
    user = await get_or_create_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
    )
    
    token = create_access_token(message.from_user.id)
    web_url = f"{settings.web_base_url}/auth?token={token}"
    
    await message.reply(
        "🌐 **Web Interface**\n\n"
        "Click the link below to access your files:\n"
        f"👉 {web_url}\n\n"
        "__(Link expires in 15 minutes)__"
    )


@tg_client.on_message(filters.command("login") & filters.private)
async def login_command(client, message: Message):
    """
    Handle login command.
    Usage:
    /login <CODE> - Link TV/Web session
    /login - Generate code to enter on device
    """
    await get_or_create_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
    )

    # Check if code is provided (TV/Web -> User flow)
    if len(message.command) > 1:
        code_input = message.command[1].strip().upper()
        
        async with async_session() as db:
            result = await db.execute(select(LoginCode).where(LoginCode.code == code_input))
            login_code = result.scalar_one_or_none()
            
            if not login_code:
                await message.reply("❌ **Invalid code.**\nPlease check the code displayed on your TV.")
                return
            
            if login_code.expires_at < datetime.utcnow():
                await message.reply("❌ **Code expired.**\nPlease generate a new one on your TV.")
                return
                
            if login_code.telegram_id:
                await message.reply("❌ **Code already used.**")
                return

            # Claim the code
            login_code.telegram_id = message.from_user.id
            await db.commit()
            
            await message.reply(
                "✅ **Success!**\n"
                "You have successfully logged in on your TV.\n"
                "You can now put your phone away and enjoy watching! 🍿"
            )
        return

    # Use secrets for cryptographically strong random number generation
    alphabet = string.ascii_uppercase + string.digits
    code = ''.join(secrets.choice(alphabet) for _ in range(6))
    
    async with async_session() as db:
        # Save code
        login_code = LoginCode(
            code=code,
            telegram_id=message.from_user.id,
            expires_at=datetime.utcnow() + timedelta(minutes=5)
        )
        db.add(login_code)
        await db.commit()
    
    await message.reply(
        "🔑 **Your Login Code:**\n\n"
        f"`{code}`\n\n"
        "Enter this code on the login screen.\n"
        "__(Expires in 5 minutes)__"
    )

    return

@tg_client.on_message(filters.command("logout_all") & filters.private)
async def logout_all_command(client, message: Message):
    """
    Invalidate all active sessions for the current user.
    """
    await get_or_create_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
    )
    
    await message.reply(
        "⚠️ **Confirm Global Logout**\n\n"
        "Are you sure you want to log out from **ALL** devices?\n"
        "This will invalidate your session on:\n"
        "• Web App\n"
        "• Android TV\n"
        "• Mobile App",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ Yes, Logout", callback_data="logout_all_confirm"),
                InlineKeyboardButton("❌ Cancel", callback_data="logout_all_cancel")
            ]
        ])
    )

# ============== File Handler ==============

@tg_client.on_message(filters.private & (filters.video | filters.audio | filters.document | filters.photo))
async def handle_file(client, message: Message):
    """Handle uploaded files - forward to channel and save to DB."""
    # Get or create user
    user = await get_or_create_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
    )
    
    # Determine file type and extract metadata
    if message.video:
        media = message.video
        file_type = "video"
    elif message.audio:
        media = message.audio
        file_type = "audio"
    elif message.document:
        media = message.document
        file_type = "document"
    elif message.photo:
        return await message.reply("❌ Photos are not supported yet.")
    else:
        return
    
    status_msg = await message.reply("📥 Processing file...")
    
    try:
        # Forward to storage channel
        forwarded = await forward_to_storage_channel(message)
        
        # Extract file info
        raw_filename = getattr(media, "file_name", None) or f"{file_type}_{message.id}"
        file_info = {
            "file_id": media.file_id,
            "file_unique_id": media.file_unique_id,
            "file_name": sanitize_filename(raw_filename),
            "file_size": media.file_size,
            "mime_type": getattr(media, "mime_type", None),
            "duration": getattr(media, "duration", None),
            "width": getattr(media, "width", None),
            "height": getattr(media, "height", None),
            "thumbnail_file_id": media.thumbs[0].file_id if getattr(media, "thumbs", None) else None,
        }
        
        # Save to database
        async with async_session() as db:
            file = File(
                user_id=user.id,
                channel_message_id=forwarded.id,
                file_type=file_type,
                **file_info
            )
            db.add(file)
            await db.commit()
            await db.refresh(file)
        
        # Build response
        emoji = {"video": "🎬", "audio": "🎵", "document": "📄", "image": "🖼"}.get(file_type, "📎")
        
        response = (
            f"✅ **File saved!**\n\n"
            f"{emoji} **{file_info['file_name']}**\n"
            f"🆔 File ID: `{file.id}`\n"
            f"📦 Size: {format_size(file_info['file_size'])}\n"
            f"🎭 Type: {file_type}\n"
        )
        
        if file_info['duration']:
            response += f"⏱ Duration: {format_duration(file_info['duration'])}\n"
        
        response += f"\n📁 Folder: / (root)\n\n"
        response += f"💡 Use `/file {file.id}` to manage this file"
        
        await status_msg.edit(
            response,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("✏️ Rename", callback_data=f"renamefile:{file.id}"),
                    InlineKeyboardButton("📂 Move", callback_data=f"move:{file.id}"),
                ],
                [
                    InlineKeyboardButton("🗑 Delete", callback_data=f"delfile:{file.id}"),
                    InlineKeyboardButton("🔗 Share", callback_data=f"sharefile:{file.id}"),
                ],
            ])
        )
        
    except Exception as e:
        await status_msg.edit(f"❌ Failed to process file: {str(e)}")


# ============== Callback Query Handlers ==============

@tg_client.on_callback_query()
async def handle_callback(client, callback: CallbackQuery):
    """Handle inline button callbacks."""
    data = callback.data
    
    if data == "logout_all_confirm":
        # Perform global logout
        async with async_session() as db:
            result = await db.execute(select(User).where(User.telegram_id == callback.from_user.id))
            user = result.scalar_one_or_none()
            
            if user:
                user.auth_version += 1
                await db.commit()
                await callback.message.edit(
                    "✅ **All sessions invalidated!**\n"
                    "You have been successfully logged out from all web, TV, and mobile devices."
                )
            else:
                await callback.answer("User not found", show_alert=True)
        await callback.answer()
        
    elif data == "logout_all_cancel":
        # Cancel logout
        await callback.message.edit("❌ **Global logout cancelled.**")
        await callback.answer()

    elif data == "get_web_link":
        # Fallback for old messages - show link and also provide Mini App button
        token = create_access_token(callback.from_user.id)
        web_url = f"{settings.web_base_url}/auth?token={token}"
        await callback.message.reply(
            f"🌐 **Web Interface**\n\n"
            f"👉 {web_url}\n\n"
            "__(Link expires in 15 minutes)__\n\n"
            "💡 Tap the button below to open directly:",
            reply_markup=InlineKeyboardMarkup([
                [get_web_app_button(callback.from_user.id, "🚀 Open Mini App")]
            ])
        )
        await callback.answer()
        
    elif data == "show_files":
        # Show recent files similar to /myfiles command
        async with async_session() as db:
            result = await db.execute(
                select(File)
                .where(File.user_id == (
                    select(User.id).where(User.telegram_id == callback.from_user.id).scalar_subquery()
                ))
                .order_by(File.created_at.desc())
                .limit(10)
            )
            files = result.scalars().all()
        
        if not files:
            await callback.message.reply(
                "📭 You haven't uploaded any files yet.\n\n"
                "Send me a video, audio, or document to get started!"
            )
            await callback.answer()
            return
        
        text = "📁 **Your Recent Files:**\n\n"
        
        for f in files:
            emoji = {"video": "🎬", "audio": "🎵", "document": "📄", "image": "🖼"}.get(f.file_type, "📎")
            text += f"{emoji} `{f.id}` | {f.file_name}\n   └ {format_size(f.file_size)}\n\n"
        
        text += "💡 Use /file <id> to manage a file"
        
        await callback.message.reply(
            text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📂 My Folders", callback_data="back_folders")],
                [get_web_app_button(callback.from_user.id, "🌐 Open Web")]
            ])
        )
        await callback.answer()
        
    elif data == "create_folder":
        # Interactive folder creation using listener
        await callback.message.reply(
            "📁 **Create New Folder**\n\n"
            "Send me the folder name:\n"
            "__(or send /cancel to abort)__"
        )
        await callback.answer()
        
        try:
            # Wait for user's reply (60 second timeout)
            reply = await client.wait_for_message(
                chat_id=callback.message.chat.id,
                timeout=60
            )
            
            if reply.text and reply.text.startswith("/cancel"):
                await reply.reply("❌ Folder creation cancelled.")
                return
            
            folder_name = reply.text.strip() if reply.text else None
            
            if not folder_name:
                await reply.reply("❌ Invalid folder name.")
                return
            
            # Create folder
            async with async_session() as db:
                user_result = await db.execute(
                    select(User).where(User.telegram_id == callback.from_user.id)
                )
                user = user_result.scalar_one_or_none()
                
                if not user:
                    await reply.reply("Please use /start first.")
                    return
                
                # Check if exists
                existing = await db.execute(
                    select(Folder).where(
                        Folder.user_id == user.id,
                        Folder.name == folder_name,
                        Folder.parent_id.is_(None)
                    )
                )
                if existing.scalar_one_or_none():
                    await reply.reply(f"❌ Folder **{folder_name}** already exists.")
                    return
                
                folder = Folder(user_id=user.id, name=folder_name)
                db.add(folder)
                await db.commit()
            
            await reply.reply(f"✅ Folder **{folder_name}** created!")
            
        except Exception as e:
            if "timeout" in str(e).lower():
                await callback.message.reply("⏱ Timed out. Please try again.")
            else:
                await callback.message.reply(f"❌ Error: {str(e)}")
        
    elif data.startswith("folder:"):
        folder_id = int(data.split(":")[1])
        async with async_session() as db:
            # Get folder
            result = await db.execute(select(Folder).where(Folder.id == folder_id))
            folder = result.scalar_one_or_none()
            
            if not folder:
                await callback.answer("Folder not found", show_alert=True)
                return
            
            # Get files in folder
            files_result = await db.execute(
                select(File).where(File.folder_id == folder_id).limit(10)
            )
            files = files_result.scalars().all()
        
        text = f"📂 **{folder.name}**\n\n"
        
        if not files:
            text += "__No files in this folder__\n"
        else:
            for f in files:
                emoji = {"video": "🎬", "audio": "🎵", "document": "📄", "image": "🖼"}.get(f.file_type, "📎")
                text += f"{emoji} `{f.id}` | {f.file_name}\n   └ {format_size(f.file_size)}\n\n"
            text += "💡 Use /file <id> to manage a file"
        
        # Add folder management buttons
        buttons = [
            [
                InlineKeyboardButton("✏️ Rename", callback_data=f"renamefolder:{folder_id}"),
                InlineKeyboardButton("🗑 Delete", callback_data=f"delfolder:{folder_id}"),
            ],
            [InlineKeyboardButton("« Back to Folders", callback_data="back_folders")]
        ]
        
        await callback.message.edit(text, reply_markup=InlineKeyboardMarkup(buttons))
        
    elif data == "back_folders":
        # Go back to folder list
        async with async_session() as db:
            user_result = await db.execute(
                select(User).where(User.telegram_id == callback.from_user.id)
            )
            user = user_result.scalar_one_or_none()
            
            if not user:
                await callback.answer("Please use /start first", show_alert=True)
                return
            
            result = await db.execute(
                select(Folder)
                .where(Folder.user_id == user.id, Folder.parent_id.is_(None))
                .order_by(Folder.name)
            )
            folders = result.scalars().all()
        
        if not folders:
            await callback.message.edit(
                "📁 You don't have any folders yet.\n\n"
                "Create one with /newfolder <name>",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("➕ Create Folder", callback_data="create_folder")]
                ])
            )
        else:
            buttons = []
            for f in folders:
                buttons.append([
                    InlineKeyboardButton(f"📂 {f.name}", callback_data=f"folder:{f.id}")
                ])
            buttons.append([InlineKeyboardButton("➕ Create Folder", callback_data="create_folder")])
            
            await callback.message.edit("📁 **Your Folders:**", reply_markup=InlineKeyboardMarkup(buttons))
        
        await callback.answer()
        
    elif data.startswith("move:"):
        file_id = int(data.split(":")[1])
        
        async with async_session() as db:
            # Get user
            user_result = await db.execute(
                select(User).where(User.telegram_id == callback.from_user.id)
            )
            user = user_result.scalar_one_or_none()
            
            if not user:
                await callback.answer("Please use /start first", show_alert=True)
                return
            
            # Get folders
            folders_result = await db.execute(
                select(Folder).where(Folder.user_id == user.id).order_by(Folder.name)
            )
            folders = folders_result.scalars().all()
        
        if not folders:
            await callback.answer("No folders yet. Create one with /newfolder", show_alert=True)
            return
        
        buttons = []
        for f in folders:
            buttons.append([
                InlineKeyboardButton(f"📂 {f.name}", callback_data=f"moveto:{file_id}:{f.id}")
            ])
        buttons.append([InlineKeyboardButton("📁 Root (no folder)", callback_data=f"moveto:{file_id}:0")])
        
        await callback.message.edit_reply_markup(InlineKeyboardMarkup(buttons))
        await callback.answer()
        
    elif data.startswith("moveto:"):
        _, file_id, folder_id = data.split(":")
        file_id = int(file_id)
        folder_id = int(folder_id) if folder_id != "0" else None
        
        async with async_session() as db:
            result = await db.execute(select(File).where(File.id == file_id))
            file = result.scalar_one_or_none()
            
            if file:
                file.folder_id = folder_id
                await db.commit()
                await callback.answer("✅ File moved!", show_alert=True)
            else:
                await callback.answer("File not found", show_alert=True)
                
    # ============== New File Management Callbacks ==============
    
    elif data.startswith("renamefile:"):
        file_id = int(data.split(":")[1])
        
        async with async_session() as db:
            result = await db.execute(select(File).where(File.id == file_id))
            file = result.scalar_one_or_none()
            
            if not file:
                await callback.answer("File not found", show_alert=True)
                return
            
            current_name = file.file_name
        
        await callback.message.reply(
            f"✏️ **Rename File**\n\n"
            f"Current name: `{current_name}`\n\n"
            "Send me the new name:\n"
            "__(or send /cancel to abort)__"
        )
        await callback.answer()
        
        try:
            reply = await client.wait_for_message(
                chat_id=callback.message.chat.id,
                timeout=60
            )
            
            if reply.text and reply.text.startswith("/cancel"):
                await reply.reply("❌ Rename cancelled.")
                return
            
            new_name = reply.text.strip() if reply.text else None
            
            if not new_name:
                await reply.reply("❌ Invalid name.")
                return
            
            async with async_session() as db:
                result = await db.execute(select(File).where(File.id == file_id))
                file = result.scalar_one_or_none()
                
                if file:
                    file.file_name = new_name
                    await db.commit()
                    await reply.reply(f"✅ File renamed to **{new_name}**")
                else:
                    await reply.reply("❌ File not found.")
                    
        except Exception as e:
            if "timeout" in str(e).lower():
                await callback.message.reply("⏱ Timed out. Please try again.")
    
    elif data.startswith("delfile:"):
        file_id = int(data.split(":")[1])
        
        async with async_session() as db:
            result = await db.execute(select(File).where(File.id == file_id))
            file = result.scalar_one_or_none()
            
            if not file:
                await callback.answer("File not found", show_alert=True)
                return
                
            file_name = file.file_name
        
        # Ask for confirmation
        await callback.message.edit(
            f"🗑 **Delete File?**\n\n"
            f"Are you sure you want to delete:\n"
            f"`{file_name}`\n\n"
            "⚠️ This action cannot be undone!",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("✅ Yes, Delete", callback_data=f"confirmdelfile:{file_id}"),
                    InlineKeyboardButton("❌ Cancel", callback_data="canceldel"),
                ]
            ])
        )
        await callback.answer()
        
    elif data.startswith("confirmdelfile:"):
        file_id = int(data.split(":")[1])
        
        async with async_session() as db:
            result = await db.execute(select(File).where(File.id == file_id))
            file = result.scalar_one_or_none()
            
            if not file:
                await callback.answer("File not found", show_alert=True)
                return
            
            file_name = file.file_name
            channel_msg_id = file.channel_message_id
            
            # Delete from database
            await db.delete(file)
            await db.commit()
        
        # Delete from Telegram channel
        from .telegram import delete_from_storage_channel
        await delete_from_storage_channel(channel_msg_id)
        
        await callback.message.edit(f"✅ File **{file_name}** deleted successfully!")
        await callback.answer("File deleted", show_alert=True)
        
    elif data.startswith("renamefolder:"):
        folder_id = int(data.split(":")[1])
        
        async with async_session() as db:
            result = await db.execute(select(Folder).where(Folder.id == folder_id))
            folder = result.scalar_one_or_none()
            
            if not folder:
                await callback.answer("Folder not found", show_alert=True)
                return
            
            current_name = folder.name
        
        await callback.message.reply(
            f"✏️ **Rename Folder**\n\n"
            f"Current name: `{current_name}`\n\n"
            "Send me the new name:\n"
            "__(or send /cancel to abort)__"
        )
        await callback.answer()
        
        try:
            reply = await client.wait_for_message(
                chat_id=callback.message.chat.id,
                timeout=60
            )
            
            if reply.text and reply.text.startswith("/cancel"):
                await reply.reply("❌ Rename cancelled.")
                return
            
            new_name = reply.text.strip() if reply.text else None
            
            if not new_name:
                await reply.reply("❌ Invalid name.")
                return
            
            async with async_session() as db:
                result = await db.execute(select(Folder).where(Folder.id == folder_id))
                folder = result.scalar_one_or_none()
                
                if folder:
                    folder.name = new_name
                    await db.commit()
                    await reply.reply(f"✅ Folder renamed to **{new_name}**")
                else:
                    await reply.reply("❌ Folder not found.")
                    
        except Exception as e:
            if "timeout" in str(e).lower():
                await callback.message.reply("⏱ Timed out. Please try again.")
    
    elif data.startswith("delfolder:"):
        folder_id = int(data.split(":")[1])
        
        async with async_session() as db:
            result = await db.execute(select(Folder).where(Folder.id == folder_id))
            folder = result.scalar_one_or_none()
            
            if not folder:
                await callback.answer("Folder not found", show_alert=True)
                return
            
            folder_name = folder.name
            
            # Check if folder has files
            files_count = await db.execute(
                select(func.count()).where(File.folder_id == folder_id)
            )
            count = files_count.scalar() or 0
        
        # Ask for confirmation
        text = (
            f"🗑 **Delete Folder?**\n\n"
            f"Folder: **{folder_name}**\n"
        )
        
        if count > 0:
            text += f"\n⚠️ This folder contains **{count} file(s)**.\nFiles will be moved to root folder."
        
        await callback.message.edit(
            text,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("✅ Yes, Delete", callback_data=f"confirmdelfolder:{folder_id}"),
                    InlineKeyboardButton("❌ Cancel", callback_data="back_folders"),
                ]
            ])
        )
        await callback.answer()
        
    elif data.startswith("confirmdelfolder:"):
        folder_id = int(data.split(":")[1])
        
        async with async_session() as db:
            result = await db.execute(select(Folder).where(Folder.id == folder_id))
            folder = result.scalar_one_or_none()
            
            if not folder:
                await callback.answer("Folder not found", show_alert=True)
                return
            
            folder_name = folder.name
            
            # Move files to root first
            from sqlalchemy import update
            await db.execute(
                update(File)
                .where(File.folder_id == folder_id)
                .values(folder_id=None)
            )
            
            # Delete folder
            await db.delete(folder)
            await db.commit()
        
        await callback.message.edit(f"✅ Folder **{folder_name}** deleted successfully!")
        await callback.answer("Folder deleted", show_alert=True)
    
    elif data.startswith("sharefile:"):
        file_id = int(data.split(":")[1])
        
        async with async_session() as db:
            # Verify ownership
            user_result = await db.execute(
                select(User).where(User.telegram_id == callback.from_user.id)
            )
            user = user_result.scalar_one_or_none()
            
            if not user:
                await callback.answer("Please use /start first", show_alert=True)
                return
            
            result = await db.execute(
                select(File).where(File.id == file_id, File.user_id == user.id)
            )
            file = result.scalar_one_or_none()
            
            if not file:
                await callback.answer("File not found", show_alert=True)
                return
            
            # Generate public hash
            file.public_hash = secrets.token_hex(16)
            await db.commit()
            await db.refresh(file)
            
            public_url = f"{settings.web_base_url}/api/stream/s/{file.public_hash}"
        
        await callback.message.reply(
            f"🔗 **Public Link Generated!**\n\n"
            f"Stream URL:\n`{public_url}`\n\n"
            "Anyone with this link can stream the file.\n"
            "Use the button below to revoke access.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔗 Unshare", callback_data=f"unsharefile:{file_id}")]
            ])
        )
        await callback.answer("Public link created!", show_alert=True)
    
    elif data.startswith("unsharefile:"):
        file_id = int(data.split(":")[1])
        
        async with async_session() as db:
            # Verify ownership
            user_result = await db.execute(
                select(User).where(User.telegram_id == callback.from_user.id)
            )
            user = user_result.scalar_one_or_none()
            
            if not user:
                await callback.answer("Please use /start first", show_alert=True)
                return
            
            result = await db.execute(
                select(File).where(File.id == file_id, File.user_id == user.id)
            )
            file = result.scalar_one_or_none()
            
            if not file:
                await callback.answer("File not found", show_alert=True)
                return
            
            file.public_hash = None
            await db.commit()
        
        await callback.message.reply(
            "🔗 **Public link revoked!**\n\n"
            "The file is no longer publicly accessible.\n"
            "You can generate a new link anytime.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔗 Share", callback_data=f"sharefile:{file_id}")]
            ])
        )
        await callback.answer("Public link revoked!", show_alert=True)
    
    elif data == "canceldel":
        await callback.message.edit("❌ Deletion cancelled.")
        await callback.answer()


# ============== File Action Command ==============

@tg_client.on_message(filters.command("file") & filters.private)
async def file_command(client, message: Message):
    """Manage a specific file by ID."""
    if len(message.command) < 2:
        await message.reply("Usage: /file <file_id>")
        return
    
    try:
        file_id = int(message.command[1])
    except ValueError:
        await message.reply("❌ Invalid file ID.")
        return
    
    async with async_session() as db:
        # Get user
        user_result = await db.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = user_result.scalar_one_or_none()
        
        if not user:
            await message.reply("Please use /start first.")
            return
        
        # Get file
        result = await db.execute(
            select(File).where(File.id == file_id, File.user_id == user.id)
        )
        file = result.scalar_one_or_none()
    
    if not file:
        await message.reply("❌ File not found or you don't have access.")
        return
    
    emoji = {"video": "🎬", "audio": "🎵", "document": "📄", "image": "🖼"}.get(file.file_type, "📎")
    
    text = (
        f"{emoji} **{file.file_name}**\n\n"
        f"📦 Size: {format_size(file.file_size)}\n"
        f"🎭 Type: {file.file_type}\n"
    )
    
    if file.duration:
        text += f"⏱ Duration: {format_duration(file.duration)}\n"
    
    if file.public_hash:
        public_url = f"{settings.web_base_url}/api/stream/s/{file.public_hash}"
        text += f"\n🔗 **Public Link:**\n`{public_url}`\n"
        share_btn = InlineKeyboardButton("🔗 Unshare", callback_data=f"unsharefile:{file.id}")
    else:
        share_btn = InlineKeyboardButton("🔗 Share", callback_data=f"sharefile:{file.id}")
    
    await message.reply(
        text,
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✏️ Rename", callback_data=f"renamefile:{file.id}"),
                InlineKeyboardButton("📂 Move", callback_data=f"move:{file.id}"),
            ],
            [
                InlineKeyboardButton("🗑 Delete", callback_data=f"delfile:{file.id}"),
                share_btn,
            ],
        ])
    )


@tg_client.on_message(filters.command("deletefolder") & filters.private)
async def deletefolder_command(client, message: Message):
    """Delete a folder by name."""
    if len(message.command) < 2:
        await message.reply("Usage: /deletefolder <folder_name>")
        return
    
    folder_name = " ".join(message.command[1:])
    
    async with async_session() as db:
        # Get user
        user_result = await db.execute(
            select(User).where(User.telegram_id == message.from_user.id)
        )
        user = user_result.scalar_one_or_none()
        
        if not user:
            await message.reply("Please use /start first.")
            return
        
        # Find folder
        result = await db.execute(
            select(Folder).where(
                Folder.user_id == user.id,
                Folder.name == folder_name
            )
        )
        folder = result.scalar_one_or_none()
    
    if not folder:
        await message.reply(f"❌ Folder **{folder_name}** not found.")
        return
    
    # Show confirmation
    await message.reply(
        f"🗑 **Delete Folder?**\n\n"
        f"Folder: **{folder_name}**\n\n"
        "Files in this folder will be moved to root.",
        reply_markup=InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ Yes, Delete", callback_data=f"confirmdelfolder:{folder.id}"),
                InlineKeyboardButton("❌ Cancel", callback_data="canceldel"),
            ]
        ])
    )

